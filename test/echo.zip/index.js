export function echo(...args) {
  return args
}